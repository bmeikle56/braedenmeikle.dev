//
//  PokerTableView.swift
//  PokerDegen
//
//  Created by Braeden Meikle on 7/7/25.
//

import SwiftUI

struct PokerTableViewLayout {
    let spacing: CGFloat
    let fontSize: CGFloat
    let iconSize: CGFloat
    let communityCardSize: CGFloat
    let playerCardSize: CGFloat
    let buttonWidth: CGFloat
    let buttonHeight: CGFloat
    let bottomPadding: CGFloat
}

struct CardImage: View {
    let name: String

    var resolvedName: String {
        
        /// we are in the middle of selecting an empty card, and don't want to render
        /// an image too early
        if name.hasPrefix("_") {
            return "card"
        } else {
            return name
        }
    }

    var body: some View {
        Image(resolvedName)
            .resizable()
            .aspectRatio(contentMode: .fit)
    }
}

struct PokerTable: View {
    var body: some View {
        GeometryReader { geo in
            let scale: CGFloat = 0.80
            let width = geo.size.width * scale
            let height = geo.size.height

            ZStack {
                // Diamond overlay texture
                Capsule()
                    .overlay(
                        DiamondPattern()
                            .clipShape(Capsule())
                            .rotation3DEffect(
                                .degrees(50),
                                axis: (x: 1, y: 0, z: 0),
                                perspective: 0.5
                            )
                    )

                // Maroon border
                Capsule()
                    .stroke(Color.pokerMaroon, lineWidth: 4)
                    .rotation3DEffect(.degrees(50), axis: (x: 1, y: 0, z: 0), perspective: 0.5)
            }
            .frame(width: width, height: height)
            .position(x: geo.size.width / 2, y: geo.size.height / 2)
            .shadow(radius: 10)
        }
        .aspectRatio(0.6, contentMode: .fit)
        .padding()
        .offset(y: CGFloat(-20))
    }
}

struct DiamondPattern: View {
    var body: some View {
        GeometryReader { geo in
            let spacing: CGFloat = 30
            let columns = Int(geo.size.width / spacing) + 2
            let rows = Int(geo.size.height / spacing) + 2

            let color1 = Color.green.opacity(0.1)
            let color2 = Color.green.opacity(0.1)

            ZStack {
                Color.green.opacity(0.3)
                ForEach(0..<columns, id: \.self) { i in
                    ForEach(0..<rows, id: \.self) { j in
                        DiamondShape()
                            .fill((i + j).isMultiple(of: 2) ? color1 : color2)
                            .frame(width: spacing, height: spacing)
                            .position(
                                x: CGFloat(i) * spacing,
                                y: CGFloat(j) * spacing
                            )
                        
                    }
                }
            }
        }
    }
}

struct DiamondShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let centerX = rect.midX
        let centerY = rect.midY

        path.move(to: CGPoint(x: centerX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX, y: centerY))
        path.addLine(to: CGPoint(x: centerX, y: rect.maxY))
        path.addLine(to: CGPoint(x: rect.minX, y: centerY))
        path.closeSubpath()

        return path
    }
}

struct CardView: View {
    let onTap: (Binding<String>) -> Void
    var size: CGFloat
    var rotation: Double = 0

    @Binding var card: String
    
    @State private var tapCount = 0

    var body: some View {
        CardImage(name: card)
            .scaledToFit()
            .frame(width: size, height: size)
            .rotationEffect(.degrees(rotation))
            .onTapGesture {
                tapCount += 1
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                    if tapCount == 1 {
                        onTap($card)
                    } else if tapCount == 2 {
                        card = "card"
                    }
                    tapCount = 0
                }
            }
    }
}

struct VillainCardView: View {
    let navigationController: UINavigationController
    let playerCardSize: CGFloat
    
    @ObservedObject var viewModel: HandViewModel

    private func select(card: Binding<String>) {
        let hostingController = UIHostingController(rootView: CardSelector(
            navigationController: navigationController,
            card: card
        ))
        hostingController.modalPresentationStyle = .overCurrentContext
        hostingController.view.backgroundColor = .clear
        navigationController.modalPresentationStyle = .overCurrentContext
        navigationController.present(hostingController, animated: true)
    }

    var body: some View {
        VStack {
            HStack(spacing: -29.0) {
                CardView(
                    onTap: select,
                    size: playerCardSize,
                    rotation: -9,
                    card: $viewModel.v1c1
                )
                CardView(
                    onTap: select,
                    size: playerCardSize,
                    rotation: 9,
                    card: $viewModel.v1c2
                )
            }
        }
    }
}

struct CommunityCardView: View {
    let navigationController: UINavigationController
    let communityCardSize: CGFloat
    
    @ObservedObject var viewModel: HandViewModel

    private func select(card: Binding<String>) {
        let hostingController = UIHostingController(rootView: CardSelector(
            navigationController: navigationController,
            card: card
        ))
        hostingController.modalPresentationStyle = .overCurrentContext
        hostingController.view.backgroundColor = .clear
        navigationController.modalPresentationStyle = .overCurrentContext
        navigationController.present(hostingController, animated: true)
    }

    var body: some View {
        VStack {
            Spacer().frame(height: 10)
            HStack(spacing: -14.0) {
                CardView(
                    onTap: select,
                    size: communityCardSize,
                    card: $viewModel.cc1
                )
                CardView(
                    onTap: select,
                    size: communityCardSize,
                    card: $viewModel.cc2
                )
                CardView(
                    onTap: select,
                    size: communityCardSize,
                    card: $viewModel.cc3
                )
                CardView(
                    onTap: select,
                    size: communityCardSize,
                    card: $viewModel.cc4
                )
                CardView(
                    onTap: select,
                    size: communityCardSize,
                    card: $viewModel.cc5
                )
            }
        }
    }
}

struct HeroCardView: View {
    let navigationController: UINavigationController
    let playerCardSize: CGFloat
    
    @ObservedObject var viewModel: HandViewModel

    private func select(card: Binding<String>) {
        let hostingController = UIHostingController(rootView: CardSelector(
            navigationController: navigationController,
            card: card
        ))
        hostingController.modalPresentationStyle = .overCurrentContext
        hostingController.view.backgroundColor = .clear
        navigationController.modalPresentationStyle = .overCurrentContext
        navigationController.present(hostingController, animated: true)
    }

    var body: some View {
        VStack {
            HStack(spacing: -29.0) {
                CardView(
                    onTap: select,
                    size: playerCardSize,
                    rotation: -9,
                    card: $viewModel.hc1
                )
                CardView(
                    onTap: select,
                    size: playerCardSize,
                    rotation: 9,
                    card: $viewModel.hc2
                )
            }
        }
    }
}

struct AnalyzeButtonView: View {
    @Binding var showPopover: Bool
    @Binding var modelResponse: [String]?
    @ObservedObject var viewModel: HandViewModel
    let fontSize: CGFloat
    let iconSize: CGFloat

    var body: some View {
        VStack {
            Button(action: {
                Task {
                    modelResponse = nil
                    modelResponse = try await analyze(viewModel: viewModel)
                }
            }, label: {
                Text("Analyze")
                    .foregroundStyle(Color.pdBlue)
                    .font(.system(size: fontSize))
                .padding()
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color.pdBlue, lineWidth: 2)
                )
            })
            .onChange(of: modelResponse, { _, _ in
                showPopover = true
            })
        }
    }
}

struct StackedChipsView: View {
    let count: Int
    let type: String

    var body: some View {
        ZStack {
            ForEach(0..<count, id: \.self) { index in
                let reverseIndex = 2 - index
                Image(type)
                    .resizable()
                    .frame(width: 40, height: 40)
                    .offset(y: CGFloat(index) * -8)
                    .rotation3DEffect(
                        .degrees(50),
                        axis: (x: 1, y: 0, z: 0),
                        perspective: 0.5
                    )
                    .scaleEffect(1.0 - CGFloat(reverseIndex) * 0.09)
            }
        }
    }
}

struct VillainStackedChipsView: View {
    let navigationController: UINavigationController

    @ObservedObject var viewModel: HandViewModel
    
    private func selectVillainBet() {
        let hostingController = UIHostingController(rootView: BetSelector(
            navigationController: navigationController,
            bet: $viewModel.vfb
        ))
        hostingController.modalPresentationStyle = .overCurrentContext
        hostingController.view.backgroundColor = .clear
        navigationController.modalPresentationStyle = .overCurrentContext
        navigationController.present(hostingController, animated: true)
    }

    var body: some View {
        VStack {
            Button(action: {
                selectVillainBet()
            }, label: {
                betUI(for: viewModel.vfb)
                    .padding(8)
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(style: StrokeStyle(lineWidth: 2, dash: [6]))
                            .foregroundColor(.gray.opacity(0.5))
                    )
            })
        }
    }
}

struct HeroStackedChipsView: View {
    let navigationController: UINavigationController

    @ObservedObject var viewModel: HandViewModel
    
    private func selectHeroBet() {
        let hostingController = UIHostingController(rootView: BetSelector(
            navigationController: navigationController,
            bet: $viewModel.hfb
        ))
        hostingController.modalPresentationStyle = .overCurrentContext
        hostingController.view.backgroundColor = .clear
        navigationController.modalPresentationStyle = .overCurrentContext
        navigationController.present(hostingController, animated: true)
    }

    var body: some View {
        VStack {
            Button(action: {
                selectHeroBet()
            }, label: {
                betUI(for: viewModel.hfb)
                    .padding(8)
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(style: StrokeStyle(lineWidth: 2, dash: [6]))
                            .foregroundColor(.gray.opacity(0.5))
                    )
            })
        }
    }
}

struct HeroPositionView: View {
    let navigationController: UINavigationController
    let fontSize: CGFloat
    @ObservedObject var viewModel: HandViewModel
    
    private func selectHeroPosition() {
        let hostingController = UIHostingController(rootView: PositionSelector(
            navigationController: navigationController,
            selectedPosition: $viewModel.hp
        ))
        hostingController.modalPresentationStyle = .overCurrentContext
        hostingController.view.backgroundColor = .clear
        navigationController.modalPresentationStyle = .overCurrentContext
        navigationController.present(hostingController, animated: true)
    }

    var body: some View {
        VStack {
            Button(action: {
                selectHeroPosition()
            }, label: {
                Text(viewModel.hp)
                    .foregroundStyle(Color.white)
                    .font(.system(size: fontSize))
                    .padding(12)
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(style: StrokeStyle(lineWidth: 2, dash: [6]))
                            .foregroundColor(.gray.opacity(0.5))
                    )
                
            })
        }
    }
}

struct VillainPositionView: View {
    let navigationController: UINavigationController
    let fontSize: CGFloat
    @ObservedObject var viewModel: HandViewModel
    
    private func selectVillainPosition() {
        let hostingController = UIHostingController(rootView: PositionSelector(
            navigationController: navigationController,
            selectedPosition: $viewModel.vp
        ))
        hostingController.modalPresentationStyle = .overCurrentContext
        hostingController.view.backgroundColor = .clear
        navigationController.modalPresentationStyle = .overCurrentContext
        navigationController.present(hostingController, animated: true)
    }

    var body: some View {
        VStack {
            Button(action: {
                selectVillainPosition()
            }, label: {
                Text(viewModel.vp)
                    .foregroundStyle(Color.white)
                    .font(.system(size: fontSize))
                    .padding(12)
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(style: StrokeStyle(lineWidth: 2, dash: [6]))
                            .foregroundColor(.gray.opacity(0.5))
                    )
            })
        }
    }
}

struct VillainPlayerTypeView: View {
    let navigationController: UINavigationController
    let fontSize: CGFloat
    @ObservedObject var viewModel: HandViewModel
    
    private func selectVillainPlayerType() {
        let hostingController = UIHostingController(rootView: PlayerTypeSelector(
            navigationController: navigationController,
            selectedPlayerType: $viewModel.vpt
        ))
        hostingController.modalPresentationStyle = .overCurrentContext
        hostingController.view.backgroundColor = .clear
        navigationController.modalPresentationStyle = .overCurrentContext
        navigationController.present(hostingController, animated: true)
    }

    var body: some View {
        VStack {
            Button(action: {
                selectVillainPlayerType()
            }, label: {
                Text(viewModel.vpt)
                    .foregroundStyle(Color.white)
                    .font(.system(size: fontSize))
                    .padding(12)
                    .background(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(style: StrokeStyle(lineWidth: 2, dash: [6]))
                            .foregroundColor(.gray.opacity(0.5))
                    )
                
            })
        }
    }
}

struct HelpButtonView: View {
    let navigationController: UINavigationController
    let iconSize: CGFloat
    @State private var showHelp = false

    var body: some View {
        Button(action: {
            let hostingController = UIHostingController(rootView: HelpView(
                navigationController: navigationController,
                layout: Layout.helpView[currentDeviceType]!
            ))
            hostingController.modalPresentationStyle = .overFullScreen
            hostingController.view.backgroundColor = .clear
            navigationController.modalPresentationStyle = .overFullScreen
            navigationController.present(hostingController, animated: true)
        }) {
            Image(systemName: "questionmark.circle")
                .font(.system(size: iconSize))
                .foregroundStyle(Color.pdBlue)
        }
    }
}

struct PokerTableView: View {
    let navigationController: UINavigationController
    let layout: PokerTableViewLayout
    @ObservedObject var authViewModel: AuthViewModel
    
    private func select(card: Binding<String>) {
        let hostingController = UIHostingController(rootView: CardSelector(
            navigationController: navigationController,
            card: card
        ))
        hostingController.modalPresentationStyle = .overCurrentContext
        hostingController.view.backgroundColor = .clear
        navigationController.modalPresentationStyle = .overCurrentContext
        navigationController.present(hostingController, animated: true)
    }
    
    @State private var showPopover = false
    @State private var modelResponse: [String]?
    @StateObject private var viewModel = HandViewModel()

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            PokerTable()
            VStack {
                HStack {
                    SettingsButtonView(
                        navigationController: navigationController,
                        iconSize: layout.iconSize,
                        authViewModel: authViewModel
                    )
                    HelpButtonView(
                        navigationController: navigationController,
                        iconSize: layout.iconSize
                    )
                    Spacer()
                }
                .padding(.horizontal, 30)
                Spacer()
            }
            .padding(.vertical, 10)
            VStack(spacing: layout.spacing) {
                HStack {
                    VillainPlayerTypeView(
                        navigationController: navigationController,
                        fontSize: layout.fontSize,
                        viewModel: viewModel
                    )
                    VillainPositionView(
                        navigationController: navigationController,
                        fontSize: layout.fontSize,
                        viewModel: viewModel
                    )
                }
                VillainCardView(
                    navigationController: navigationController,
                    playerCardSize: layout.playerCardSize,
                    viewModel: viewModel
                )
                VillainStackedChipsView(
                    navigationController: navigationController,
                    viewModel: viewModel
                )
                CommunityCardView(
                    navigationController: navigationController,
                    communityCardSize: layout.communityCardSize,
                    viewModel: viewModel
                )
                HeroStackedChipsView(
                    navigationController: navigationController,
                    viewModel: viewModel
                )
                HeroCardView(
                    navigationController: navigationController,
                    playerCardSize: layout.playerCardSize,
                    viewModel: viewModel
                )
                HeroPositionView(
                    navigationController: navigationController,
                    fontSize: layout.fontSize,
                    viewModel: viewModel
                )
                AnalyzeButtonView(
                    showPopover: $showPopover,
                    modelResponse: $modelResponse,
                    viewModel: viewModel,
                    fontSize: layout.fontSize,
                    iconSize: layout.iconSize
                )
                .popover(isPresented: $showPopover) {
                    AnalyzeView(
                        layout: Layout.analyzeView[currentDeviceType]!,
                        showPopover: $showPopover,
                        modelResponse: $modelResponse
                    )
                }
            }
        }
        .navigationBarHidden(true)
    }
}

struct SettingsButtonView: View {
    let navigationController: UINavigationController
    let iconSize: CGFloat
    @ObservedObject var authViewModel: AuthViewModel

    var body: some View {
        Button(action: {
            let hostingController = UIHostingController(rootView: SettingsView(
                navigationController: navigationController,
                authViewModel: authViewModel,
                layout: Layout.settingsView[currentDeviceType]!
            ))
            hostingController.modalPresentationStyle = .overFullScreen
            hostingController.view.backgroundColor = .clear
            navigationController.modalPresentationStyle = .overFullScreen
            navigationController.present(hostingController, animated: true)
        }) {
            Image(systemName: "gear")
                .font(.system(size: iconSize))
                .foregroundStyle(Color.pdBlue)
        }
    }
}

struct MarkdownView: View {
    let markdownString: String

    var body: some View {
        if let attributed = try? AttributedString(markdown: markdownString) {
            Text(attributed)
                .padding()
        } else {
            Text(markdownString)
                .foregroundColor(.red)
        }
    }
}

/// iPhone
#Preview("iPhone") {
    PokerTableView(
        navigationController: UINavigationController(),
        layout: Layout.pokerTableView[.iPhone]!,
        authViewModel: AuthViewModel()
    )
}

/// iPad
#Preview("iPad") {
    PokerTableView(
        navigationController: UINavigationController(),
        layout: Layout.pokerTableView[.iPad]!,
        authViewModel: AuthViewModel()
    )
}
